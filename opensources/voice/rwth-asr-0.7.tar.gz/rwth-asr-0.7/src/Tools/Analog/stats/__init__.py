import os,sys
sys.path[0:0] = [ os.path.join(dir, '..') for dir in __path__ ]
